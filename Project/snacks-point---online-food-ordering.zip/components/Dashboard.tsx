import React, { useState, useEffect } from 'react';
import { Search, Tag, ShoppingCart, MapPin, ChevronRight, Loader2 } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { FoodCard } from './FoodCard';
import { CATEGORIES } from '../constants';
import { fetchMenuItems, fetchItemsByCategory } from '../services/api';
import { MenuItem, CartItem, User } from '../types';

interface DashboardProps {
  user: User;
  onLogout: () => void;
  cart: CartItem[];
  addToCart: (item: MenuItem) => void;
  wishlist: Set<string>;
  toggleWishlist: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
    user, 
    onLogout, 
    cart, 
    addToCart,
    wishlist,
    toggleWishlist
}) => {
  const [activeTab, setActiveTab] = useState('menu');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const items = await fetchItemsByCategory(selectedCategory);
        setMenuItems(items);
      } catch (error) {
        console.error("Failed to load menu", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [selectedCategory]);

  const filteredItems = menuItems.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white md:pl-64 transition-all">
      <Sidebar 
        onLogout={onLogout} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
      />

      <main className="p-4 md:p-8 max-w-7xl mx-auto">
        {/* Top Header */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div className="flex items-center gap-2 md:w-auto w-full">
                <h2 className="text-yellow-500 font-bold text-sm hidden md:block">2 client hit for this app!</h2>
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                 {/* Search Bar */}
                <div className="relative group">
                    <div className="flex items-center gap-2 border border-red-200 rounded-full px-4 py-2 bg-white hover:shadow-sm transition-shadow">
                        <Search size={16} className="text-red-500" />
                        <input 
                            type="text" 
                            placeholder="Search" 
                            className="outline-none text-sm text-gray-600 w-24 md:w-32 focus:w-48 transition-all"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                </div>

                <button className="flex items-center gap-2 border border-red-200 rounded-full px-4 py-2 bg-white hover:bg-red-50 text-red-500 text-sm font-medium transition-colors">
                    <Tag size={16} />
                    <span>Offers</span>
                </button>

                 <button 
                    onClick={() => setActiveTab('cart')}
                    className="flex items-center gap-2 border border-red-200 rounded-full px-4 py-2 bg-white hover:bg-red-50 text-red-500 text-sm font-medium transition-colors"
                 >
                    <ShoppingCart size={16} />
                    <span>{cartCount} Items</span>
                </button>
                
                <button className="flex items-center gap-2 border border-red-200 rounded-full px-4 py-2 bg-white hover:bg-red-50 text-red-500 text-sm font-medium transition-colors">
                    <MapPin size={16} />
                    <span>Address</span>
                </button>

                 {/* Mobile Logout (visible only on small screens) */}
                 <button onClick={onLogout} className="md:hidden border border-gray-200 p-2 rounded-full">
                    <Loader2 size={16} />
                 </button>
            </div>
        </header>

        {activeTab === 'cart' ? (
             <div className="max-w-2xl mx-auto">
                <h2 className="text-3xl font-bold text-red-400 mb-6">Your Cart</h2>
                {cart.length === 0 ? (
                    <div className="text-center py-20 text-gray-400">
                        <ShoppingCart size={48} className="mx-auto mb-4 opacity-50" />
                        <p>Your cart is empty.</p>
                        <button onClick={() => setActiveTab('menu')} className="mt-4 text-red-500 font-bold hover:underline">Go to Menu</button>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {cart.map(item => (
                            <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                                <div className="flex items-center gap-4">
                                    <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover" />
                                    <div>
                                        <h4 className="font-bold text-gray-800">{item.name}</h4>
                                        <p className="text-gray-500 text-sm">${item.price} x {item.quantity}</p>
                                    </div>
                                </div>
                                <span className="font-bold text-lg">${item.price * item.quantity}</span>
                            </div>
                        ))}
                        <div className="border-t border-gray-200 pt-6 mt-6">
                            <div className="flex justify-between items-center text-xl font-bold mb-4">
                                <span>Total</span>
                                <span>${cartTotal}</span>
                            </div>
                            <button className="w-full py-4 bg-red-500 text-white rounded-xl font-bold shadow-lg hover:bg-red-600 transition-colors">
                                Checkout Now
                            </button>
                        </div>
                    </div>
                )}
             </div>
        ) : (
            <div className="flex flex-col lg:flex-row gap-8">
                {/* Main Menu Area */}
                <div className="flex-1">
                    <div className="flex items-center gap-4 mb-6 overflow-x-auto pb-2 scrollbar-hide">
                         <h1 className="text-4xl font-bold text-red-400 mr-8 capitalize">
                            {selectedCategory === 'all' ? 'Menu' : selectedCategory}
                         </h1>
                    </div>

                    {loading ? (
                        <div className="flex items-center justify-center h-64">
                            <Loader2 className="animate-spin text-red-400" size={48} />
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredItems.map(item => (
                                <FoodCard 
                                    key={item.id} 
                                    item={item} 
                                    onAddToCart={addToCart}
                                    onToggleWishlist={toggleWishlist}
                                    isWishlisted={wishlist.has(item.id)}
                                />
                            ))}
                        </div>
                    )}
                </div>

                {/* Right Sidebar - "Go For Hunt" */}
                <div className="w-full lg:w-64 flex-shrink-0">
                    <h3 className="text-2xl font-bold text-red-400 mb-6">Go For Hunt</h3>
                    <div className="space-y-4">
                        {CATEGORIES.filter(c => c.id !== 'all').map(cat => (
                             <button
                                key={cat.id}
                                onClick={() => setSelectedCategory(cat.id)}
                                className={`w-full flex items-center gap-4 p-3 rounded-full transition-all group ${
                                    selectedCategory === cat.id ? 'bg-white shadow-md ring-2 ring-red-100' : 'hover:bg-gray-50'
                                }`}
                            >
                                <div className="w-12 h-12 rounded-full bg-orange-100 overflow-hidden relative">
                                    <img 
                                        src={`https://picsum.photos/seed/${cat.id}/200/200`} 
                                        alt={cat.name}
                                        className="w-full h-full object-cover"
                                    />
                                </div>
                                <span className={`font-medium ${selectedCategory === cat.id ? 'text-gray-900' : 'text-gray-600 group-hover:text-gray-900'}`}>
                                    {cat.name}
                                </span>
                                {selectedCategory === cat.id && <ChevronRight size={16} className="ml-auto text-red-400" />}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        )}
      </main>
    </div>
  );
};