import React from 'react';
import { Star, Heart, Plus } from 'lucide-react';
import { MenuItem } from '../types';

interface FoodCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem) => void;
  onToggleWishlist: (id: string) => void;
  isWishlisted: boolean;
}

export const FoodCard: React.FC<FoodCardProps> = ({ item, onAddToCart, onToggleWishlist, isWishlisted }) => {
  return (
    <div className="bg-pink-50 rounded-3xl p-4 shadow-sm hover:shadow-md transition-shadow relative group">
      {/* Wishlist Button */}
      <button 
        onClick={() => onToggleWishlist(item.id)}
        className="absolute top-4 right-4 z-10 w-8 h-8 flex items-center justify-center rounded-full bg-white shadow-sm hover:scale-110 transition-transform"
      >
        <Heart 
            size={16} 
            className={`${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
        />
      </button>

      {/* Rating Badge */}
      <div className="absolute top-4 left-4 z-10 bg-black text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
        <Star size={10} className="fill-yellow-400 text-yellow-400" />
        <span>{item.rating}</span>
      </div>

      {/* Image */}
      <div className="w-full h-40 rounded-full overflow-hidden mb-4 border-4 border-white shadow-inner mx-auto max-w-[160px]">
        <img 
            src={item.image} 
            alt={item.name} 
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      {/* Content */}
      <div className="text-center">
        <h3 className="font-bold text-gray-800 text-lg mb-1">{item.name}</h3>
        <p className="text-gray-500 text-xs mb-3 line-clamp-1">{item.description}</p>
        
        <div className="flex items-center justify-between mt-2">
            <span className="text-gray-900 font-bold">Price : $ {item.price}</span>
            <button 
                onClick={() => onAddToCart(item)}
                className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-full shadow-lg hover:shadow-red-200 transition-all active:scale-95"
            >
                <Plus size={18} />
            </button>
        </div>
      </div>
    </div>
  );
};