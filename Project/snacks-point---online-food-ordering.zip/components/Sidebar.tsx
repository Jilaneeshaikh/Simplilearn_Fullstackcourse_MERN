import React from 'react';
import { ShoppingBag, Info, Heart, ShoppingCart, Phone, LayoutDashboard, LogOut } from 'lucide-react';

interface SidebarProps {
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onLogout, activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'menu', icon: <LayoutDashboard size={20} />, label: 'Menu' },
    { id: 'about', icon: <Info size={20} />, label: 'About' },
    { id: 'services', icon: <ShoppingBag size={20} />, label: 'Services' },
    { id: 'orders', icon: <ShoppingBag size={20} />, label: 'Your Orders' },
    { id: 'wishlist', icon: <Heart size={20} />, label: 'Wishlists' },
    { id: 'contact', icon: <Phone size={20} />, label: 'Contact' },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-white shadow-xl flex flex-col z-20 hidden md:flex">
      {/* Brand */}
      <div className="p-8">
        <div className="flex items-center gap-2">
          <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center overflow-hidden border border-gray-100">
             <span className="text-xl font-bold font-serif italic text-gray-800">Snacks</span>
          </div>
          <div>
            <h1 className="font-bold text-xl italic font-serif leading-none">Snacks</h1>
            <p className="text-sm font-semibold italic text-gray-600">Point</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-6 py-3 rounded-xl transition-all duration-200 ${
              activeTab === item.id
                ? 'bg-red-50 text-red-500 font-semibold shadow-sm'
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
        
        {/* Cart Item - Special Case */}
         <button
            onClick={() => setActiveTab('cart')}
            className={`w-full flex items-center gap-4 px-6 py-3 rounded-xl transition-all duration-200 ${
              activeTab === 'cart'
                ? 'bg-red-50 text-red-500 font-semibold shadow-sm'
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
            }`}
          >
            <ShoppingCart size={20} />
            <span>Cart</span>
          </button>
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-100">
        <button 
            onClick={onLogout}
            className="w-full flex items-center gap-4 px-6 py-3 text-gray-500 hover:bg-red-50 hover:text-red-500 rounded-xl transition-colors"
        >
            <LogOut size={20} />
            <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};