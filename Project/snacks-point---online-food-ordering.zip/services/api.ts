import { MenuItem } from '../types';
import { MOCK_MENU_ITEMS } from '../constants';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const fetchMenuItems = async (): Promise<MenuItem[]> => {
  await delay(800); // Simulate 800ms server response time
  return [...MOCK_MENU_ITEMS];
};

export const fetchItemsByCategory = async (category: string): Promise<MenuItem[]> => {
  await delay(500);
  if (category === 'all') return [...MOCK_MENU_ITEMS];
  return MOCK_MENU_ITEMS.filter(item => item.category === category);
};

export const placeOrder = async (items: any[]): Promise<{ success: boolean; orderId: string }> => {
  await delay(1500);
  return { success: true, orderId: Math.random().toString(36).substr(2, 9) };
};